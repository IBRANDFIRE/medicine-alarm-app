package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.data.model.DoseStatus
import com.example.data.model.MealInstruction
import com.example.ui.TodayDoseItem
import com.example.ui.components.TodayDoseCard
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    composeTestRule.setContent {
      MyApplicationTheme {
        TodayDoseCard(
          item = TodayDoseItem(
            medicineId = 1L,
            medicineName = "Amoxicillin",
            dosage = "500 mg",
            time = "08:00",
            mealInstruction = MealInstruction.AFTER_FOOD,
            instructionText = MealInstruction.AFTER_FOOD.title,
            status = DoseStatus.PENDING,
            colorHex = 0xFF0F766E,
            iconName = "PILL",
            slotIndex = 0,
            notes = "Take with water"
          ),
          onTake = {},
          onSnooze = {},
          onSkip = {},
          onUndo = {}
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }
}
