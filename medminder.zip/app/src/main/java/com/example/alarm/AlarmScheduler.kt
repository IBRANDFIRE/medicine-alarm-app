package com.example.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.MainActivity
import com.example.data.model.Medicine
import java.util.Calendar

object AlarmScheduler {

    private const val TAG = "AlarmScheduler"
    const val ACTION_MEDICINE_ALARM = "com.example.ACTION_MEDICINE_ALARM"
    const val ACTION_DOSE_TAKEN = "com.example.ACTION_DOSE_TAKEN"
    const val ACTION_DOSE_SNOOZE = "com.example.ACTION_DOSE_SNOOZE"

    const val EXTRA_MEDICINE_ID = "extra_medicine_id"
    const val EXTRA_MEDICINE_NAME = "extra_medicine_name"
    const val EXTRA_DOSAGE = "extra_dosage"
    const val EXTRA_INSTRUCTION = "extra_instruction"
    const val EXTRA_TIME = "extra_time"
    const val EXTRA_SLOT_INDEX = "extra_slot_index"
    const val EXTRA_IS_TEST = "extra_is_test"

    fun scheduleMedicineAlarms(context: Context, medicine: Medicine) {
        if (!medicine.isActive) {
            cancelMedicineAlarms(context, medicine)
            return
        }

        medicine.timesOfDay.forEachIndexed { index, timeStr ->
            scheduleSingleAlarm(context, medicine, timeStr, index)
        }
    }

    fun scheduleSingleAlarm(
        context: Context,
        medicine: Medicine,
        timeStr: String,
        slotIndex: Int
    ) {
        val parts = timeStr.split(":")
        if (parts.size != 2) return
        val hour = parts[0].toIntOrNull() ?: return
        val minute = parts[1].toIntOrNull() ?: return

        val now = Calendar.getInstance()
        val triggerCal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        // If the scheduled time today has already elapsed, schedule for tomorrow
        if (triggerCal.before(now)) {
            triggerCal.add(Calendar.DAY_OF_YEAR, 1)
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val requestCode = generateRequestCode(medicine.id, slotIndex)

        val intent = Intent(context, MedicineAlarmReceiver::class.java).apply {
            action = ACTION_MEDICINE_ALARM
            putExtra(EXTRA_MEDICINE_ID, medicine.id)
            putExtra(EXTRA_MEDICINE_NAME, medicine.name)
            putExtra(EXTRA_DOSAGE, medicine.dosage)
            putExtra(EXTRA_INSTRUCTION, "${medicine.mealInstruction.emoji} ${medicine.getEffectiveInstruction()}")
            putExtra(EXTRA_TIME, timeStr)
            putExtra(EXTRA_SLOT_INDEX, slotIndex)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val showIntent = Intent(context, MainActivity::class.java)
        val showPendingIntent = PendingIntent.getActivity(
            context,
            requestCode,
            showIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setAlarmClock(
                    AlarmManager.AlarmClockInfo(triggerCal.timeInMillis, showPendingIntent),
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    triggerCal.timeInMillis,
                    pendingIntent
                )
            }
            Log.d(TAG, "Scheduled alarm for ${medicine.name} at ${triggerCal.time}")
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException while scheduling exact alarm", e)
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                triggerCal.timeInMillis,
                pendingIntent
            )
        }
    }

    fun cancelMedicineAlarms(context: Context, medicine: Medicine) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        // Cancel all potential slots up to 10
        for (i in 0 until 10) {
            val requestCode = generateRequestCode(medicine.id, i)
            val intent = Intent(context, MedicineAlarmReceiver::class.java).apply {
                action = ACTION_MEDICINE_ALARM
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pendingIntent != null) {
                alarmManager.cancel(pendingIntent)
                pendingIntent.cancel()
            }
        }
    }

    fun scheduleSnoozeAlarm(
        context: Context,
        medicineId: Long,
        medicineName: String,
        dosage: String,
        instruction: String,
        time: String,
        snoozeMinutes: Int = 10
    ) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val triggerTime = System.currentTimeMillis() + (snoozeMinutes * 60 * 1000L)
        val requestCode = (medicineId * 100 + 99).toInt()

        val intent = Intent(context, MedicineAlarmReceiver::class.java).apply {
            action = ACTION_MEDICINE_ALARM
            putExtra(EXTRA_MEDICINE_ID, medicineId)
            putExtra(EXTRA_MEDICINE_NAME, medicineName)
            putExtra(EXTRA_DOSAGE, dosage)
            putExtra(EXTRA_INSTRUCTION, instruction)
            putExtra(EXTRA_TIME, time)
            putExtra(EXTRA_SLOT_INDEX, 99)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerTime,
                pendingIntent
            )
        } catch (e: Exception) {
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                triggerTime,
                pendingIntent
            )
        }
    }

    fun scheduleTestAlarm(context: Context, secondsFromNow: Int = 5) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val triggerTime = System.currentTimeMillis() + (secondsFromNow * 1000L)
        val requestCode = 999999

        val intent = Intent(context, MedicineAlarmReceiver::class.java).apply {
            action = ACTION_MEDICINE_ALARM
            putExtra(EXTRA_MEDICINE_ID, -1L)
            putExtra(EXTRA_MEDICINE_NAME, "Amoxicillin (Test Dose)")
            putExtra(EXTRA_DOSAGE, "500 mg")
            putExtra(EXTRA_INSTRUCTION, "🍽️ After eating food")
            putExtra(EXTRA_TIME, "Now")
            putExtra(EXTRA_SLOT_INDEX, 0)
            putExtra(EXTRA_IS_TEST, true)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerTime,
                pendingIntent
            )
        } catch (e: Exception) {
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                triggerTime,
                pendingIntent
            )
        }
    }

    private fun generateRequestCode(medicineId: Long, slotIndex: Int): Int {
        return (medicineId * 100 + slotIndex).toInt()
    }
}
