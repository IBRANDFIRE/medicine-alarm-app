package com.example.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.MedicineAlarmApp
import com.example.data.model.DoseStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MedicineAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        Log.d(TAG, "onReceive action: $action")

        val medicineId = intent.getLongExtra(AlarmScheduler.EXTRA_MEDICINE_ID, -1L)
        val medicineName = intent.getStringExtra(AlarmScheduler.EXTRA_MEDICINE_NAME) ?: "Medicine"
        val dosage = intent.getStringExtra(AlarmScheduler.EXTRA_DOSAGE) ?: ""
        val instruction = intent.getStringExtra(AlarmScheduler.EXTRA_INSTRUCTION) ?: ""
        val time = intent.getStringExtra(AlarmScheduler.EXTRA_TIME) ?: ""
        val slotIndex = intent.getIntExtra(AlarmScheduler.EXTRA_SLOT_INDEX, 0)
        val isTest = intent.getBooleanExtra(AlarmScheduler.EXTRA_IS_TEST, false)

        when (action) {
            AlarmScheduler.ACTION_MEDICINE_ALARM -> {
                NotificationHelper.showDoseNotification(
                    context = context,
                    medicineId = medicineId,
                    medicineName = medicineName,
                    dosage = dosage,
                    instruction = instruction,
                    time = time,
                    isTest = isTest
                )

                // Reschedule for tomorrow if it's a real scheduled alarm
                if (!isTest && medicineId > 0) {
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            val repo = (context.applicationContext as? MedicineAlarmApp)?.repository
                            val med = repo?.getMedicineByIdSync(medicineId)
                            if (med != null && med.isActive) {
                                AlarmScheduler.scheduleSingleAlarm(context, med, time, slotIndex)
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to reschedule alarm", e)
                        }
                    }
                }
            }

            AlarmScheduler.ACTION_DOSE_TAKEN -> {
                val notificationId = intent.getIntExtra("notification_id", if (medicineId > 0) medicineId.toInt() else 9999)
                NotificationHelper.dismissNotification(context, notificationId)

                if (medicineId > 0) {
                    val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                    val todayStr = dateFormat.format(Date())

                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            val repo = (context.applicationContext as? MedicineAlarmApp)?.repository
                            repo?.recordDoseAction(
                                medicineId = medicineId,
                                medicineName = medicineName,
                                dosage = dosage,
                                mealInstructionText = instruction,
                                date = todayStr,
                                time = time,
                                status = DoseStatus.TAKEN
                            )
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to record dose taken", e)
                        }
                    }
                }
            }

            AlarmScheduler.ACTION_DOSE_SNOOZE -> {
                val notificationId = intent.getIntExtra("notification_id", if (medicineId > 0) medicineId.toInt() else 9999)
                NotificationHelper.dismissNotification(context, notificationId)

                AlarmScheduler.scheduleSnoozeAlarm(
                    context = context,
                    medicineId = medicineId,
                    medicineName = medicineName,
                    dosage = dosage,
                    instruction = instruction,
                    time = time,
                    snoozeMinutes = 10
                )
            }
        }
    }

    companion object {
        private const val TAG = "MedicineAlarmReceiver"
    }
}
