package com.example.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.MedicineAlarmApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED
        ) {
            Log.d("BootReceiver", "Rescheduling active medicine alarms after: $action")
            val app = context.applicationContext as? MedicineAlarmApp ?: return

            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val activeMeds = app.repository.getActiveMedicinesSync()
                    for (med in activeMeds) {
                        AlarmScheduler.scheduleMedicineAlarms(context, med)
                    }
                    Log.d("BootReceiver", "Successfully rescheduled ${activeMeds.size} medicines")
                } catch (e: Exception) {
                    Log.e("BootReceiver", "Error rescheduling alarms", e)
                }
            }
        }
    }
}
