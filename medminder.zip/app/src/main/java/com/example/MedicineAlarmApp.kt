package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import com.example.data.db.MedicineDatabase
import com.example.data.repository.MedicineRepository

class MedicineAlarmApp : Application() {

    lateinit var database: MedicineDatabase
        private set

    lateinit var repository: MedicineRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        database = MedicineDatabase.getDatabase(this)
        repository = MedicineRepository(database.medicineDao(), database.doseLogDao())
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_ALARM)
                .build()

            val channel = NotificationChannel(
                CHANNEL_ID,
                "Medicine Dose Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Urgent alarms and notifications for scheduled medicine doses"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 250, 500, 250, 500)
                setSound(alarmSound, audioAttributes)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                setShowBadge(true)
            }

            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "medicine_reminders_channel"
        lateinit var instance: MedicineAlarmApp
            private set
    }
}
