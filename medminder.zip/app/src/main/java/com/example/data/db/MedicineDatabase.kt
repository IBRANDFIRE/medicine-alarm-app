package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.DoseLog
import com.example.data.model.MealInstruction
import com.example.data.model.Medicine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [Medicine::class, DoseLog::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class MedicineDatabase : RoomDatabase() {

    abstract fun medicineDao(): MedicineDao
    abstract fun doseLogDao(): DoseLogDao

    companion object {
        @Volatile
        private var INSTANCE: MedicineDatabase? = null

        fun getDatabase(context: Context): MedicineDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MedicineDatabase::class.java,
                    "medicine_alarm_db"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Populate initial helpful examples
                            CoroutineScope(Dispatchers.IO).launch {
                                INSTANCE?.let { database ->
                                    populateInitialData(database.medicineDao())
                                }
                            }
                        }
                    })
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun populateInitialData(dao: MedicineDao) {
            val sample1 = Medicine(
                name = "Amoxicillin",
                dosage = "500 mg (1 capsule)",
                mealInstruction = MealInstruction.AFTER_FOOD,
                customInstruction = "",
                timesOfDay = listOf("08:00", "20:00"),
                colorHex = 0xFF0D9488, // Medical Teal
                iconName = "CAPSULE",
                notes = "Antibiotic course. Drink plenty of water."
            )
            val sample2 = Medicine(
                name = "Omeprazole",
                dosage = "20 mg (1 tablet)",
                mealInstruction = MealInstruction.EMPTY_STOMACH,
                customInstruction = "",
                timesOfDay = listOf("07:00"),
                colorHex = 0xFF0284C7, // Blue
                iconName = "TABLET",
                notes = "Take 30-60 min before breakfast."
            )
            val sample3 = Medicine(
                name = "Vitamin D3",
                dosage = "1000 IU",
                mealInstruction = MealInstruction.WITH_FOOD,
                customInstruction = "",
                timesOfDay = listOf("13:00"),
                colorHex = 0xFFD97706, // Amber
                iconName = "PILL",
                notes = "Take with main meal for better absorption."
            )
            dao.insertMedicine(sample1)
            dao.insertMedicine(sample2)
            dao.insertMedicine(sample3)
        }
    }
}
