package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.DoseLog
import com.example.data.model.DoseStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface DoseLogDao {

    @Query("SELECT * FROM dose_logs WHERE scheduledDate = :date ORDER BY scheduledTime ASC")
    fun getLogsForDate(date: String): Flow<List<DoseLog>>

    @Query("SELECT * FROM dose_logs WHERE scheduledDate = :date")
    suspend fun getLogsForDateSync(date: String): List<DoseLog>

    @Query("SELECT * FROM dose_logs WHERE medicineId = :medicineId AND scheduledDate = :date AND scheduledTime = :time LIMIT 1")
    suspend fun getLog(medicineId: Long, date: String, time: String): DoseLog?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: DoseLog): Long

    @Update
    suspend fun updateLog(log: DoseLog)

    @Query("UPDATE dose_logs SET status = :status, actionTimestamp = :timestamp WHERE id = :id")
    suspend fun updateStatus(id: Long, status: DoseStatus, timestamp: Long)

    @Query("SELECT * FROM dose_logs ORDER BY id DESC LIMIT :limit")
    fun getRecentLogs(limit: Int = 50): Flow<List<DoseLog>>

    @Query("DELETE FROM dose_logs WHERE medicineId = :medicineId")
    suspend fun deleteLogsForMedicine(medicineId: Long)
}
