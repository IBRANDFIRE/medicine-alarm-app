package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class DoseStatus {
    PENDING,
    TAKEN,
    SKIPPED,
    SNOOZED
}

@Entity(tableName = "dose_logs")
data class DoseLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val medicineId: Long,
    val medicineName: String,
    val dosage: String,
    val mealInstructionText: String,
    val scheduledDate: String, // Format: YYYY-MM-DD
    val scheduledTime: String, // Format: HH:mm
    val status: DoseStatus = DoseStatus.PENDING,
    val actionTimestamp: Long? = null
)
