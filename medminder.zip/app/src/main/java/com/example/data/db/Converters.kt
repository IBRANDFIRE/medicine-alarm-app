package com.example.data.db

import androidx.room.TypeConverter
import com.example.data.model.DoseStatus
import com.example.data.model.MealInstruction

class Converters {

    @TypeConverter
    fun fromMealInstruction(value: MealInstruction): String {
        return value.name
    }

    @TypeConverter
    fun toMealInstruction(value: String): MealInstruction {
        return try {
            MealInstruction.valueOf(value)
        } catch (e: Exception) {
            MealInstruction.AFTER_FOOD
        }
    }

    @TypeConverter
    fun fromDoseStatus(value: DoseStatus): String {
        return value.name
    }

    @TypeConverter
    fun toDoseStatus(value: String): DoseStatus {
        return try {
            DoseStatus.valueOf(value)
        } catch (e: Exception) {
            DoseStatus.PENDING
        }
    }

    @TypeConverter
    fun fromStringList(list: List<String>): String {
        return list.joinToString(separator = ",")
    }

    @TypeConverter
    fun toStringList(data: String): List<String> {
        if (data.isBlank()) return emptyList()
        return data.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }

    @TypeConverter
    fun fromIntList(list: List<Int>): String {
        return list.joinToString(separator = ",")
    }

    @TypeConverter
    fun toIntList(data: String): List<Int> {
        if (data.isBlank()) return emptyList()
        return data.split(",").mapNotNull { it.trim().toIntOrNull() }
    }
}
