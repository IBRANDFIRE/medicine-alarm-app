package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.example.data.db.Converters

enum class MealInstruction(
    val title: String,
    val description: String,
    val emoji: String
) {
    AFTER_FOOD(
        title = "After eating food",
        description = "Take within 30 minutes after finishing food/meal",
        emoji = "🍽️"
    ),
    EMPTY_STOMACH(
        title = "Empty stomach",
        description = "Take 1 hour before or 2 hours after meal for best absorption",
        emoji = "⏳"
    ),
    BEFORE_FOOD(
        title = "Before eating food",
        description = "Take 20–30 minutes before meal",
        emoji = "🥗"
    ),
    WITH_FOOD(
        title = "With food / meal",
        description = "Take alongside food during your meal",
        emoji = "🍲"
    ),
    BEDTIME(
        title = "Before bedtime",
        description = "Take 15–30 minutes before sleep at night",
        emoji = "🌙"
    ),
    WITH_WATER(
        title = "With full glass of water",
        description = "Drink at least 250ml water, do not crush or chew",
        emoji = "💧"
    ),
    CUSTOM(
        title = "Custom instruction",
        description = "Follow specific doctor instructions",
        emoji = "📋"
    )
}

@Entity(tableName = "medicines")
data class Medicine(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val dosage: String, // e.g. "500 mg", "1 tablet", "2 drops", "10 ml"
    val mealInstruction: MealInstruction = MealInstruction.AFTER_FOOD,
    val customInstruction: String = "",
    val timesOfDay: List<String> = listOf("08:00"), // Formatted as "HH:mm"
    val daysOfWeek: List<Int> = listOf(1, 2, 3, 4, 5, 6, 7), // 1=Mon, 7=Sun
    val isActive: Boolean = true,
    val colorHex: Long = 0xFF0D9488,
    val iconName: String = "PILL",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun getEffectiveInstruction(): String {
        return if (mealInstruction == MealInstruction.CUSTOM && customInstruction.isNotBlank()) {
            customInstruction
        } else {
            mealInstruction.title
        }
    }
}
