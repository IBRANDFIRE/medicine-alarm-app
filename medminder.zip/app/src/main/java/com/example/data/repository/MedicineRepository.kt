package com.example.data.repository

import com.example.data.db.DoseLogDao
import com.example.data.db.MedicineDao
import com.example.data.model.DoseLog
import com.example.data.model.DoseStatus
import com.example.data.model.Medicine
import kotlinx.coroutines.flow.Flow

class MedicineRepository(
    private val medicineDao: MedicineDao,
    private val doseLogDao: DoseLogDao
) {
    val allMedicines: Flow<List<Medicine>> = medicineDao.getAllMedicines()
    val activeMedicines: Flow<List<Medicine>> = medicineDao.getActiveMedicines()

    suspend fun getActiveMedicinesSync(): List<Medicine> {
        return medicineDao.getActiveMedicinesSync()
    }

    fun getMedicineById(id: Long): Flow<Medicine?> {
        return medicineDao.getMedicineById(id)
    }

    suspend fun getMedicineByIdSync(id: Long): Medicine? {
        return medicineDao.getMedicineByIdSync(id)
    }

    suspend fun insertMedicine(medicine: Medicine): Long {
        return medicineDao.insertMedicine(medicine)
    }

    suspend fun updateMedicine(medicine: Medicine) {
        medicineDao.updateMedicine(medicine)
    }

    suspend fun deleteMedicine(medicine: Medicine) {
        doseLogDao.deleteLogsForMedicine(medicine.id)
        medicineDao.deleteMedicine(medicine)
    }

    suspend fun deleteMedicineById(id: Long) {
        doseLogDao.deleteLogsForMedicine(id)
        medicineDao.deleteMedicineById(id)
    }

    suspend fun setMedicineActive(id: Long, isActive: Boolean) {
        medicineDao.setMedicineActive(id, isActive)
    }

    fun getLogsForDate(date: String): Flow<List<DoseLog>> {
        return doseLogDao.getLogsForDate(date)
    }

    suspend fun recordDoseAction(
        medicineId: Long,
        medicineName: String,
        dosage: String,
        mealInstructionText: String,
        date: String,
        time: String,
        status: DoseStatus
    ) {
        val existing = doseLogDao.getLog(medicineId, date, time)
        val now = System.currentTimeMillis()
        if (existing != null) {
            doseLogDao.updateStatus(existing.id, status, now)
        } else {
            val newLog = DoseLog(
                medicineId = medicineId,
                medicineName = medicineName,
                dosage = dosage,
                mealInstructionText = mealInstructionText,
                scheduledDate = date,
                scheduledTime = time,
                status = status,
                actionTimestamp = now
            )
            doseLogDao.insertLog(newLog)
        }
    }

    fun getRecentLogs(limit: Int = 50): Flow<List<DoseLog>> {
        return doseLogDao.getRecentLogs(limit)
    }
}
