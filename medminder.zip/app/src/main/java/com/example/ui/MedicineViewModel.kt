package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.MedicineAlarmApp
import com.example.alarm.AlarmScheduler
import com.example.data.model.DoseLog
import com.example.data.model.DoseStatus
import com.example.data.model.MealInstruction
import com.example.data.model.Medicine
import com.example.data.repository.MedicineRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class TodayDoseItem(
    val medicineId: Long,
    val medicineName: String,
    val dosage: String,
    val time: String, // HH:mm
    val mealInstruction: MealInstruction,
    val instructionText: String,
    val status: DoseStatus,
    val colorHex: Long,
    val iconName: String,
    val slotIndex: Int,
    val notes: String
)

data class AdherenceSummary(
    val totalDoses: Int,
    val takenDoses: Int,
    val percentage: Int
)

class MedicineViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: MedicineRepository =
        (application as MedicineAlarmApp).repository

    val allMedicines: StateFlow<List<Medicine>> = repository.allMedicines
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val todayDateStr = dateFormat.format(Date())

    val todayLogs: StateFlow<List<DoseLog>> = repository.getLogsForDate(todayDateStr)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val todayDoses: StateFlow<List<TodayDoseItem>> = combine(allMedicines, todayLogs) { meds, logs ->
        val logMap = logs.associateBy { "${it.medicineId}_${it.scheduledTime}" }
        val doseList = mutableListOf<TodayDoseItem>()

        val calendar = Calendar.getInstance()
        // Day of week: Sunday = 1, Monday = 2 ... convert to 1=Mon, 7=Sun
        val dayOfWeekCalendar = calendar.get(Calendar.DAY_OF_WEEK)
        val isoDayOfWeek = if (dayOfWeekCalendar == Calendar.SUNDAY) 7 else dayOfWeekCalendar - 1

        for (med in meds) {
            if (!med.isActive) continue
            if (!med.daysOfWeek.contains(isoDayOfWeek)) continue

            med.timesOfDay.forEachIndexed { index, time ->
                val log = logMap["${med.id}_$time"]
                val status = log?.status ?: DoseStatus.PENDING

                doseList.add(
                    TodayDoseItem(
                        medicineId = med.id,
                        medicineName = med.name,
                        dosage = med.dosage,
                        time = time,
                        mealInstruction = med.mealInstruction,
                        instructionText = med.getEffectiveInstruction(),
                        status = status,
                        colorHex = med.colorHex,
                        iconName = med.iconName,
                        slotIndex = index,
                        notes = med.notes
                    )
                )
            }
        }

        // Sort chronologically by time
        doseList.sortedBy { it.time }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val adherenceSummary: StateFlow<AdherenceSummary> = todayDoses.combine(todayLogs) { doses, _ ->
        val total = doses.size
        val taken = doses.count { it.status == DoseStatus.TAKEN }
        val percent = if (total > 0) (taken * 100) / total else 100
        AdherenceSummary(totalDoses = total, takenDoses = taken, percentage = percent)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AdherenceSummary(0, 0, 100)
    )

    fun saveMedicine(
        id: Long = 0,
        name: String,
        dosage: String,
        mealInstruction: MealInstruction,
        customInstruction: String,
        timesOfDay: List<String>,
        colorHex: Long,
        notes: String
    ) {
        viewModelScope.launch {
            val medicine = Medicine(
                id = id,
                name = name.trim(),
                dosage = dosage.trim(),
                mealInstruction = mealInstruction,
                customInstruction = customInstruction.trim(),
                timesOfDay = timesOfDay.sorted(),
                colorHex = colorHex,
                notes = notes.trim()
            )

            val finalId = if (id == 0L) {
                repository.insertMedicine(medicine)
            } else {
                repository.updateMedicine(medicine)
                id
            }

            val savedMedicine = medicine.copy(id = finalId)
            AlarmScheduler.scheduleMedicineAlarms(getApplication(), savedMedicine)
        }
    }

    fun toggleMedicineActive(medicine: Medicine) {
        viewModelScope.launch {
            val newActive = !medicine.isActive
            repository.setMedicineActive(medicine.id, newActive)
            val updated = medicine.copy(isActive = newActive)
            if (newActive) {
                AlarmScheduler.scheduleMedicineAlarms(getApplication(), updated)
            } else {
                AlarmScheduler.cancelMedicineAlarms(getApplication(), updated)
            }
        }
    }

    fun deleteMedicine(medicine: Medicine) {
        viewModelScope.launch {
            AlarmScheduler.cancelMedicineAlarms(getApplication(), medicine)
            repository.deleteMedicine(medicine)
        }
    }

    fun markDoseStatus(
        item: TodayDoseItem,
        status: DoseStatus
    ) {
        viewModelScope.launch {
            repository.recordDoseAction(
                medicineId = item.medicineId,
                medicineName = item.medicineName,
                dosage = item.dosage,
                mealInstructionText = item.instructionText,
                date = todayDateStr,
                time = item.time,
                status = status
            )
        }
    }

    fun snoozeDose(item: TodayDoseItem, minutes: Int = 10) {
        viewModelScope.launch {
            AlarmScheduler.scheduleSnoozeAlarm(
                context = getApplication(),
                medicineId = item.medicineId,
                medicineName = item.medicineName,
                dosage = item.dosage,
                instruction = "${item.mealInstruction.emoji} ${item.instructionText}",
                time = item.time,
                snoozeMinutes = minutes
            )
            repository.recordDoseAction(
                medicineId = item.medicineId,
                medicineName = item.medicineName,
                dosage = item.dosage,
                mealInstructionText = item.instructionText,
                date = todayDateStr,
                time = item.time,
                status = DoseStatus.SNOOZED
            )
        }
    }

    fun triggerTestAlarm() {
        AlarmScheduler.scheduleTestAlarm(getApplication(), secondsFromNow = 5)
    }
}
