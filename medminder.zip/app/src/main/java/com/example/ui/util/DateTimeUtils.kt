package com.example.ui.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateTimeUtils {

    fun formatTo12Hour(time24: String): String {
        return try {
            val parts = time24.split(":")
            if (parts.size != 2) return time24
            val hour = parts[0].toInt()
            val minute = parts[1].toInt()
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
            }
            val formatter = SimpleDateFormat("h:mm a", Locale.getDefault())
            formatter.format(cal.time)
        } catch (e: Exception) {
            time24
        }
    }

    fun getTodayFormattedHeader(): String {
        val formatter = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault())
        return formatter.format(Date())
    }

    fun isUpcoming(time24: String): Boolean {
        return try {
            val parts = time24.split(":")
            if (parts.size != 2) return false
            val hour = parts[0].toInt()
            val minute = parts[1].toInt()
            val now = Calendar.getInstance()
            val doseTime = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
            }
            doseTime.after(now)
        } catch (e: Exception) {
            false
        }
    }
}
