package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors (Clean Medical Teal & Slate)
val TealPrimary = Color(0xFF0F766E)
val TealOnPrimary = Color(0xFFFFFFFF)
val TealPrimaryContainer = Color(0xFFCCFBF1)
val TealOnPrimaryContainer = Color(0xFF115E59)

val TealSecondary = Color(0xFF0284C7)
val TealSecondaryContainer = Color(0xFFE0F2FE)
val TealOnSecondaryContainer = Color(0xFF0369A1)

val AccentAmber = Color(0xFFD97706)
val AccentAmberContainer = Color(0xFFFEF3C7)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OutlineLight = Color(0xFFCBD5E1)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)

// Dark Theme Colors
val TealPrimaryDark = Color(0xFF2DD4BF)
val TealOnPrimaryDark = Color(0xFF003833)
val TealPrimaryContainerDark = Color(0xFF134E4A)
val TealOnPrimaryContainerDark = Color(0xFFCCFBF1)

val BackgroundDark = Color(0xFF0B1320)
val SurfaceDark = Color(0xFF111E33)
val SurfaceVariantDark = Color(0xFF1E293B)
val OutlineDark = Color(0xFF334155)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
