package com.example.ui.screens

import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.MealInstruction
import com.example.data.model.Medicine
import com.example.ui.util.DateTimeUtils

val AvailableColors = listOf(
    0xFF0F766E, // Teal
    0xFF0284C7, // Blue
    0xFF7C3AED, // Violet
    0xFFE11D48, // Rose
    0xFFD97706, // Amber
    0xFF059669  // Emerald
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddEditMedicineDialog(
    initialMedicine: Medicine? = null,
    onDismiss: () -> Unit,
    onSave: (
        id: Long,
        name: String,
        dosage: String,
        instruction: MealInstruction,
        customInstruction: String,
        times: List<String>,
        colorHex: Long,
        notes: String
    ) -> Unit
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(initialMedicine?.name ?: "") }
    var dosage by remember { mutableStateOf(initialMedicine?.dosage ?: "") }
    var mealInstruction by remember { mutableStateOf(initialMedicine?.mealInstruction ?: MealInstruction.AFTER_FOOD) }
    var customInstruction by remember { mutableStateOf(initialMedicine?.customInstruction ?: "") }
    val timesOfDay = remember {
        mutableStateListOf<String>().apply {
            if (initialMedicine != null && initialMedicine.timesOfDay.isNotEmpty()) {
                addAll(initialMedicine.timesOfDay)
            } else {
                add("08:00")
            }
        }
    }
    var selectedColor by remember { mutableStateOf(initialMedicine?.colorHex ?: AvailableColors.first()) }
    var notes by remember { mutableStateOf(initialMedicine?.notes ?: "") }
    var nameError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier
            .fillMaxWidth(0.95f)
            .padding(vertical = 16.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (initialMedicine == null) "New Medicine Alarm" else "Edit Medicine",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close dialog")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Medicine Name
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        if (it.isNotBlank()) nameError = false
                    },
                    label = { Text("Medicine Name *") },
                    placeholder = { Text("e.g. Amoxicillin, Metformin, Vitamin D") },
                    isError = nameError,
                    supportingText = {
                        if (nameError) Text("Medicine name is required", color = MaterialTheme.colorScheme.error)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("medicine_name_input"),
                    singleLine = true
                )

                // Dosage
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = dosage,
                        onValueChange = { dosage = it },
                        label = { Text("Dosage / Form") },
                        placeholder = { Text("e.g. 500 mg, 1 tablet, 2 drops") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dosage_input"),
                        singleLine = true
                    )
                    // Quick dosage chips
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf("1 Tablet", "1 Capsule", "500 mg", "250 mg", "10 ml", "2 Drops").forEach { quickDosage ->
                            SuggestionChip(
                                onClick = { dosage = quickDosage },
                                label = { Text(quickDosage, fontSize = 12.sp) }
                            )
                        }
                    }
                }

                // Food / Meal Instructions
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "How does this medicine should be eaten?",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Crucial for proper absorption & stomach safety:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        MealInstruction.values().forEach { instruction ->
                            val isSelected = mealInstruction == instruction
                            FilterChip(
                                selected = isSelected,
                                onClick = { mealInstruction = instruction },
                                label = {
                                    Text("${instruction.emoji} ${instruction.title}")
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }
                    }

                    // Explanation Card for selected food instruction
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                Icons.Default.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "${mealInstruction.emoji} ${mealInstruction.title}",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = mealInstruction.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    // If Custom instruction chosen, prompt for custom text
                    if (mealInstruction == MealInstruction.CUSTOM) {
                        OutlinedTextField(
                            value = customInstruction,
                            onValueChange = { customInstruction = it },
                            label = { Text("Specific Doctor Instruction") },
                            placeholder = { Text("e.g. Dissolve in warm water, take with yogurt") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // Daily Dose Times Schedule
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Daily Alarm Times",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${timesOfDay.size} dose${if (timesOfDay.size > 1) "s" else ""} per day",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Presets Row
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            OutlinedButton(
                                onClick = {
                                    timesOfDay.clear()
                                    timesOfDay.addAll(listOf("08:00"))
                                },
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("1x", fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = {
                                    timesOfDay.clear()
                                    timesOfDay.addAll(listOf("08:00", "20:00"))
                                },
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("2x", fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = {
                                    timesOfDay.clear()
                                    timesOfDay.addAll(listOf("08:00", "14:00", "20:00"))
                                },
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("3x", fontSize = 12.sp)
                            }
                        }
                    }

                    // Times List
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        timesOfDay.forEachIndexed { index, timeStr ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.primaryContainer,
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(start = 10.dp, end = 4.dp, top = 4.dp, bottom = 4.dp)
                                ) {
                                    Icon(
                                        Icons.Default.AccessTime,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = DateTimeUtils.formatTo12Hour(timeStr),
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                    if (timesOfDay.size > 1) {
                                        IconButton(
                                            onClick = { timesOfDay.removeAt(index) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Close,
                                                contentDescription = "Remove time",
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Add Time Slot Button (opens TimePickerDialog)
                        Button(
                            onClick = {
                                val cal = java.util.Calendar.getInstance()
                                val dialog = TimePickerDialog(
                                    context,
                                    { _, selectedHour, selectedMinute ->
                                        val formatted = String.format("%02d:%02d", selectedHour, selectedMinute)
                                        if (!timesOfDay.contains(formatted)) {
                                            timesOfDay.add(formatted)
                                            timesOfDay.sort()
                                        }
                                    },
                                    cal.get(java.util.Calendar.HOUR_OF_DAY),
                                    cal.get(java.util.Calendar.MINUTE),
                                    false
                                )
                                dialog.show()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                            ),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("+ Add Time", fontSize = 13.sp)
                        }
                    }
                }

                // Color Picker
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Tag Color", style = MaterialTheme.typography.titleSmall)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AvailableColors.forEach { colorLong ->
                            val color = Color(colorLong)
                            val isSelected = selectedColor == colorLong
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .clickable { selectedColor = colorLong }
                                    .border(
                                        width = if (isSelected) 3.dp else 1.dp,
                                        color = if (isSelected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                        shape = CircleShape
                                    )
                            )
                        }
                    }
                }

                // Notes / Precautions
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Special Precautions or Notes (Optional)") },
                    placeholder = { Text("e.g. Do not take with dairy; keep in fridge") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    maxLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        nameError = true
                        return@Button
                    }
                    if (timesOfDay.isEmpty()) {
                        timesOfDay.add("08:00")
                    }
                    onSave(
                        initialMedicine?.id ?: 0L,
                        name,
                        if (dosage.isBlank()) "1 dose" else dosage,
                        mealInstruction,
                        customInstruction,
                        timesOfDay.toList(),
                        selectedColor,
                        notes
                    )
                    onDismiss()
                },
                modifier = Modifier.testTag("save_medicine_button")
            ) {
                Text(if (initialMedicine == null) "Schedule Alarm" else "Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
